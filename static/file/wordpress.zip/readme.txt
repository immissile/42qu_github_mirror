=== 42qu.com 文章作者信息插件===
Contributors: 42quTeam (admin[at]42qu.com)
Tags: 42qu, 42区,  related, related posts, 相关, 相关文章, author, author information, plugin, widget，information，pay
Requires at least: 2.5.1
Tested up to: 3.1
Stable tag: 1.0.4.9

显示作者信息，提供读者微支付 | Displays author information，provide readers micropayment.

== Description ==

"42qu.com 文章作者信息插件"是42区重要产品, 它可以在帮助博主更有效的和读者沟通 它会提供读者向博主微支付功能, 对博主分享经验是一个有效刺激.更重要的是, 一旦你的博客使用了"42qu.com 文章作者信息插件", 你的博客将会自动整合到42区, 届时你的文章将会让更多的读者看到. 此插件主要针对的是中文博客. 详情请查看:  http://42qu.com/help/donate.


<h4>功能</h4>

* 展示博主各大网站链接
* 捐赠“智能收集42区来访捐赠者资料，了解读者群
* 金钱奖励增加写作的动力，“捐赠“支持读者支付奖励金额.
* 更多强大的功能可在安装后前往42区网站管理中心查看.

--

"42qu.com authors information plugins"is an important product of 42qu, it can help bloggers and readers to communicate more effectively it will provide readers with micro-payments features to the bloggers on bloggers share their experiences is an effective stimulus. is more important Is that once your blog using the "42qu.com authors plugins", your blog will automatically be integrated into 42 areas, then your article will allow more readers to see. This plugin is targeted Chinese blog. For more information see: http://42qu.com/help/donate.


<h4>features</h4>

* show links to major websites bloggers
* donation "to collect intelligence information on 42qu，of which donor visitors to understand the audience
* Writing monetary incentives to increase the power, "donation" to pay rewards to support the amount of readers.
* More powerful features can be installed at 42qu website management center viewing.

== Installation ==

1. 下载42qu.zip.
1. 从插件管理界面上传插件.
1. 点击`现在安装`.
1. 在后台管理面板里的`用户` -> `42区绑定`可以找到插件的设置选项.

或

1. 解压缩下载的42qu.zip.
1. 将解压缩后得到的文件夹上传到WordPress `/wp-content/plugins/` 目录下.
1. 在WordPress的后台`管理插件`页面启用`42qu.com 文章作者信息插件`.

--

1. Download 42qu.zip.
1. Upload the zipped file directly in wordpress admin page.
1. Click `Install Now`.

OR

1. Download 42qu.zip and unzip it.
1. Copy the unzipped folder `42qu` to `/wp-content/plugins/`
1. Activate the plugin.
1. Go to `User -> 42qu` and customize the options you want.

== Frequently Asked Questions ==

= 装了插件后遇到问题? =

直接发个邮件给我们(admin@42qu.com), 我们会在最短时间内帮你解决.

== Screenshots ==

1. **42区 - 找到给你答案的人**
