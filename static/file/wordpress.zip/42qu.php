<?php
// Plugin Name: 42qu.com 文章作者信息插件
// Description: 设置页面位于 用户 - 42qu; 告诉网络现实世界中的你是谁。 让欣赏你的人为你的文章付费，让想结识你的人与你因缘际会。豆瓣，微博，Google Reader Share，博客中，展示自己的网络名片。
// Plugin URI:  http://fairyfish.net/2011/03/28/42qu-wordpress-plugin/
// Version: 1.0
// Author: Bolo

function update_user_meta_42qu($userid = null, $metakey = null, $new_metavalue = null, $old_metavalue = null){
	if(!$userid) return;
	if(function_exists('update_user_meta')){
		update_user_meta($userid, $metakey, $new_metavalue, $old_metavalue);
	}elseif(function_exists('update_usermeta')){
		update_usermeta($userid, $metakey, $new_metavalue);
	}else{
		return;
	}
}

function get_user_meta_42qu($userid = null, $metakey = null, $single = true){
	if(!$userid) return;
	if(function_exists('get_user_meta')){
		return get_user_meta($userid, $metakey, $single);
	}elseif(function_exists('get_usermeta')){
		return get_usermeta($userid, $metakey);
	}else{
		return;
	}
}

function refresh_profile_42qu(){
	global $current_user;
	get_currentuserinfo();
	$profile_42qu = get_user_meta_42qu($current_user->ID, 'profile_42qu', true);
	if( !class_exists( 'WP_Http' ) ) include_once( ABSPATH . WPINC. '/class-http.php' );
	$request = new WP_Http;
    $appdata = $request->request("http://api.42qu.com/man/{$profile_42qu['id']}/show", array('timeout' => 45));
	if(!$appdata->errors){
		$profile_42qu = json_decode($appdata['body'], true);
	}
	if( $profile_42qu ){
		$profile_42qu['mail'] = $profile_42qu['mail'];
		update_user_meta_42qu($current_user->ID, 'profile_42qu', $profile_42qu);
		//print_r( json_decode($appdata['body'], true) );
	}
}

class othOptions {

	function othOptions() {
		$options = get_option('42qu_options');
		if (!is_array($options)) {
			$options['mail'] = '';

			update_option('42qu_options', $options);
		}
		return $options;
	}

	function getOptions() {
		$options = get_option('42qu_options');
		return $options;
	}

	function add() {
		global $current_user;
		get_currentuserinfo();
		$profile_42qu_old = get_user_meta_42qu($current_user->ID, 'profile_42qu', true);

		if( $_REQUEST['action'] == 'checkmail' && $_POST['42qu_save'] ){
			if( !class_exists( 'WP_Http' ) ) include_once( ABSPATH . WPINC. '/class-http.php' );
            $request = new WP_Http;
            
            $blog_title = urlencode(get_bloginfo('name'));
            $blog_rss = urlencode(get_bloginfo('rss_url'));
            $blog_url = urlencode(get_bloginfo('url'));
            $blog_mail = urlencode($current_user->user_email);
            $blog_author = urlencode($current_user->display_name);

            $quurl = "http://api.42qu.com/search/man/".$_REQUEST['mail']."?blog_link=".$blog_url."&blog_ping=".$blog_rss."&id=".$profile_42qu['id']."&author=".$blog_author."&mail=".$blog_mail."&blog_title=".$blog_title;
			$appdata = $request->request($quurl, array('timeout' => 45));
			if(!$appdata->errors){
				$profile_42qu = json_decode($appdata['body'], true);
			}
			if( $profile_42qu ){
				$profile_42qu['mail'] = $_REQUEST['mail'];
				update_user_meta_42qu($current_user->ID, 'profile_42qu', $profile_42qu);
				//print_r( json_decode($appdata['body'], true) );
				wp_redirect(admin_url('users.php?page=42qu_bind&update=1'), 301);
			}else{
				wp_redirect(admin_url('users.php?page=42qu_bind&error='.urlencode('邮箱地址错误或者未注册')), 301);
			}
		}

		if($_REQUEST['refresh'] && $profile_42qu_old){
			if( !class_exists( 'WP_Http' ) ) include_once( ABSPATH . WPINC. '/class-http.php' );
			$request = new WP_Http;
			$appdata = $request->request("http://api.42qu.com/man/{$profile_42qu_old['id']}/show", array('timeout' => 45));
			//$appdata = $request->request("http://api.42qu.com/search/man/{$profile_42qu_old['mail']}", array('timeout' => 45));
			$profile_42qu_new = json_decode($appdata['body'], true);
			if( $profile_42qu_old ){
				$profile_42qu_new['mail'] = $profile_42qu_old['mail'];
				update_user_meta_42qu($current_user->ID, 'profile_42qu', $profile_42qu_new, $profile_42qu_old);
				//print_r( json_decode($appdata['body'], true) );
				wp_redirect(admin_url('users.php?page=42qu_bind&update=1'), 301);
			}
		}

		add_users_page('42区绑定', '42 区绑定', 'edit_posts', '42qu_bind', array('othOptions', 'display'));
	}

	function display() {

		$options = othOptions::getOptions();
		global $current_user;
		get_currentuserinfo();
		//print_r($current_user);






?>
<form method="post" enctype="multipart/form-data" name="ala_form" id="ala_form">
<?php $profile_42qu = get_user_meta_42qu($current_user->ID, 'profile_42qu', true); ?>
<style>
.qu42_title{font-size:16px;font-family:Georgia;
border-bottom:1px dotted #999;
padding-bottom:20px;
}
.qu42_mt20{margin-top:20px}
.qu_body a{color:#01a;text-decoration:none}
.qu42_itx{
font-family:Georgia;border:1px solid #ccc;padding:2px;font-size:16px;
}
.qu42_imail{
font-size:32px;width:400px
}
.qu42_button{
	line-height: 18px;
	padding-bottom: 10px;
	padding-left: 20px;
	padding-right: 20px;
	padding-top: 10px;
	font-size:16px;
	display:inline-block;margin:0;background-color:#fefefe;border:1px solid #ddd;font-family:\5b8b\4f53,tahoma,arialf;font-size:14px;line-height:22px;text-decoration:none;font-weight:normal;color:#444;cursor:pointer;
	width:auto;overflow:visible;
}
.qu42_b1c p{
font-size:16px;
}
.qu42_b1c{
	background:#FFF;
	border:1px solid #ccc;
	width:465px;
	margin:auto;
	margin-top:27px;
}
.qu42_form{
	padding:0 32px;
	border-bottom:0;
}
.qu42_bind span a{
margin-right:6px;
}
.qu42_bind a,.qu42_bind span{
float:left;
text-decoration:none;
font-family:Verdana;
}
.qu42_edit a{
margin-left:27px
}
.qu42_edit{
float: right;
}
.qu42_bind{
line-height:40px;
text-align:right;
}
pre{word-wrap:break-word;overflow:hidden;word-break:break-all;white-space:pre-wrap;white-space:-moz-pre-wrap;*white-space:pre;*word-wrap:break-word;
font-family:Verdana;
}
.qu42table{
width:650px;
margin:auto;
margin-bottom:32px
}
.qu42table td, .qu42table th{
padding:20px;
font-size:14px;
}
.qu42_what{
text-decoration: none; font-size: 14px;padding-right:54px
}
.qu42_what_p{
margin:auto;text-align:right;
padding-top:14px;
margin-bottom:14px;
border-top:1px dotted #ccc;
}
</style>

	<div class="wrap">
		<h2>42区帐号设置</h2>

		<?php if(!$_REQUEST['action']) : ?>

		<?php if($_REQUEST['update'] && $_REQUEST['update'] == 1) : ?>
		<div class="updated fade"><p>更新成功！到你的文章页面看看去吧 ...</p></div>
		<?php endif; ?>
<div class="qu42_b1c">
<div class="qu42_form">
<div class="qu42_mt20">

	<p>请输入您在<a href="http://42qu.com" target="_blank">42qu.com</a>的注册邮箱</p>

	<p><input class="qu42_itx qu42_imail" name="mail" type="text"
	value="<?php
		if($profile_42qu && $profile_42qu['mail']){
			$show_mail = $profile_42qu['mail'];
		}else{
			$show_mail = $current_user->user_email;
		}
		echo $show_mail
?>"
	></input></p>
	<p class="qu42_bind">
<a href="http://42qu.com" target="_blank">&gt; 没有账号? 点此注册</a>
<input class="button-primary" type="submit" name="42qu_save" value="提交修改/刷新资料"  style="font-size:16px!important;padding:5px"/>
	</p>
</div>
</div>

<p class="qu42_what_p">
	<a href="http://42qu.com/help/donate" target="_blank" class="qu42_what">这是什么?</a>

</p>

</div>


		<?php if($_REQUEST['error']) : ?>
		<div class="error fade"><p><?php echo $_REQUEST['error']; ?></p></div>
		<?php endif; ?>
			<input type="hidden" name="action" value="checkmail" />
		<?php endif; ?>
	</div>

</form>
<?php if($profile_42qu) : //print_r($profile_42qu);
$backurl = urlencode(admin_url('users.php?page=42qu_bind&update=1&refresh=1'));
$blog_title = urlencode(get_bloginfo('name'));
$blog_rss = urlencode(get_bloginfo('rss_url'));
$blog_url = urlencode(get_bloginfo('url'));
$blog_mail = urlencode($current_user->user_email);
$blog_author = urlencode($current_user->display_name);

$bind_prefix = "http://api.42qu.com/man/blog_bind?back=".$backurl."&blog_link=".$blog_url."&blog_ping=".$blog_rss."&id=".$profile_42qu['id']."&author=".$blog_author."&mail=".$blog_mail."&blog_title=".$blog_title."&next=";
//echo $bind_prefix
?>
<div style="font-size:14px;margin:20px auto 5px;background:#FFF;text-align:right;border:1px solid #eee;padding:10px;width:630px;">
<span style="float:left;">
<a href="http://42qu.com/-<?php echo $profile_42qu['id']; ?>" target="_blank"><?php echo $profile_42qu['name']; ?></a>

42区资料预览

</span>

 <a href="<?php echo $bind_prefix; ?>/me/namecard/edit" >点此修改资料</a> </div>

<table class="widefat qu42table">
	<tbody>
<?php
	/*
	<tr valign="top">
			<th scope="row">当前绑定帐号</th>
			<td>

			</td>
		</tr>
	 */
?>
		<tr valign="middle">

			<th scope="row">头像 <a href="<?php echo $bind_prefix;?>/me/pic">编辑</a></th>
			<td>
				<?php if($profile_42qu['ico']) : ?>
					<a href="http://42qu.com/-<?php echo $profile_42qu['id']; ?>" target="_blank"><img src="<?php echo $profile_42qu['ico']; ?>" /></a>
				<?php else : ?>
					<a href="<?php echo $bind_prefix;?>/me/pic" target="_blank">点此上传头像</a>
				<?php endif; ?>

			</td>
		</tr>
<?php
	/*
		<tr valign="top">
			<th scope="row">42区 ID</th>
			<td>
				<?php echo $profile_42qu['id']; ?>
			</td>
		</tr>

	 */
?>
		<tr valign="top">
			<th scope="row">主页</th>
			<td>
<?php if(!$profile_42qu['uid']){
	echo "<a href=\"".$bind_prefix."/me/manurl\">没有设置个性网址? 点此免费开通</a>";
}else{
	echo "<a href=\"http://42qu.com/{$profile_42qu['uid']}/\" target=\"_blank\">http://42qu.com/{$profile_42qu['uid']}</a>";
}?>
			</td>
		</tr>
		<tr valign="top">

			<th scope="row">公司</th>
			<td>
				<?php echo $profile_42qu['company']; ?>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">职位</th>
			<td>

				<?php echo $profile_42qu['title']; ?>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">描述
				<a href="<?php echo $bind_prefix ?>/me/namecard/sell">编辑</a>
			</th>
			<td><pre style=""><?php echo $profile_42qu['about_me']; ?></pre>
			</td>

		</tr>
		<tr valign="top">
			<th scope="row">链接
				<a href="<?php echo $bind_prefix ?>/me/namecard/link">编辑</a>
			</th>
			<td>
 <?php if($profile_42qu['link']){ ?>
<?php foreach($profile_42qu['link'] as $link) : ?>
<a href="<?php echo $link[1]; ?>" target="_blank"><?php echo $link[0]; ?></a>
<?php endforeach; ?>

<?php } ?>

			</td>
		</tr>
		<tr valign="top">
			<th scope="row" style="width:130px">被请客的出场费</th>
			<td>
				<?php echo $profile_42qu['appearance_fee']; ?> 元
				<a style="margin-left:14px" href="<?php echo $bind_prefix ?>/me/sell">修改</a>

			</td>
		</tr>
	</tbody>
</table>
<?php endif; ?>
<?php
	}
}
add_action('admin_menu', array('othOptions', 'add'));

function bind_42qu_warning(){
	global $current_user;
	get_currentuserinfo();
	$profile_42qu = get_user_meta_42qu($current_user->ID, 'profile_42qu', true);
	if(!$profile_42qu && current_user_can('edit_posts')){
		echo "<div class='updated fade'><p><a href='".admin_url('users.php?page=42qu_bind')."'>绑定42区账号</a>, 在文章下显示作者信息</p></div>";
    }else{
        $refresh = 1;
        if($refresh == mt_rand(1,41)){
            refresh_profile_42qu();
        }
    }
}
add_action('admin_notices', 'bind_42qu_warning');

function show_42qu_namecard($content){
    if(is_home()||is_archive()||is_front_page()) return $content;

	global $post;
	$permalink = get_permalink($post->ID);
	$title = urlencode(get_the_title($post->ID));
	$profile_42qu = get_user_meta_42qu($post->post_author, 'profile_42qu', true);
	//print_r($profile_42qu);
	$position = 'blog';
	if($profile_42qu['uid']){
		$user_path = $profile_42qu['uid'];
	}else{
		$user_path = '-'.$profile_42qu['id'];
	}
	$man_name = $profile_42qu['name'];
	$man_company = $profile_42qu['company'];
	$man_title = $profile_42qu['title'];

	$man_more = '';
	if($man_company)
		$man_more = $man_more.', '.$man_company;
	if($man_title)
		$man_more = $man_more.', '.$man_title;



	ob_start();
	if($profile_42qu['id'] && $profile_42qu['ico'] && (is_singular() || is_feed())) : ?>

<div id="qu42" style="border:1px solid #ccc;font-size:14px;margin:27px auto;"><div style="padding:7px 10px;border-bottom:1px dotted #ccc">关于作者</div><div style="height:129px;overflow:hidden"><a target="_blank" href="http://42qu.com/<?php echo $user_path; ?>" style="color:#000;text-decoration:none;float:right;"><img src="<?php echo $profile_42qu['ico']; ?>" style="padding:3px;width:219px;height:123px;margin:0;background:transparent;border:0;border-left:1px dotted #ccc"></a><div style="text-align:left;line-height:23px;margin-right:226px"><div style="padding:5px 10px"><div style="overflow:hidden;margin:2px 0;float:left;font-size: 14px;"><a target="_blank" href="http://42qu.com/<?php echo $user_path; ?>" style="text-decoration:none;"><?php echo $man_name; ?></a><?php echo $man_more; ?></div><div style="clear:left"><?php echo str_replace("\r\n"," ",$profile_42qu['about_me']); ?></div></div></div></div><div style="text-align:right;border-top:1px dotted #ccc;padding:10px;"><div style="float:left;"><?php if($profile_42qu['link']) : foreach($profile_42qu['link'] as $link) : ?><a target="_blank" href="<?php echo $link[1]; ?>" style="margin-right:7px;text-decoration:none;"><?php echo $link[0]; ?></a> <?php endforeach;endif; ?></div><div><a target="_blank" href="http://42qu.com/<?php echo $user_path; ?>/pay?title=<?php echo $title; ?>&url=<?php echo urlencode($permalink); ?>&rel=<?php echo $position; ?>" style="text-decoration:none;margin-right:17px">向文章付费</a> <a href="http://42qu.com/<?php echo $user_path; ?>/pay?title=<?php echo $title; ?>&url=<?php echo urlencode($permalink); ?>&cid=1&rel=<?php echo $position; ?>" style="text-decoration:none;margin-right:16px" target="_blank">请作者吃饭</a></div></div></div>
	<?php elseif($profile_42qu['id'] && !$profile_42qu['ico'] && (is_singular() || is_feed())) : ?>
<div id="qu42" style="border:1px solid #ccc;font-size:14px;margin:27px auto;"><div style="padding:7px 10px;border-bottom:1px dotted #ccc">关于作者</div><div style="overflow:hidden"><div style="text-align:left;line-height:23px;"><div style="padding:5px 10px"><div style="margin:2px 0;height:23px;overflow:hidden;font-size:14px;"><a target="_blank" href="http://42qu.com/<?php echo $user_path; ?>" style="text-decoration:none;"><?php echo $man_name; ?></a><?php echo $man_more; ?></div><div><?php echo $profile_42qu['about_me']; ?></div></div></div></div><div style="text-align:right;border-top:1px dotted #ccc;padding:10px;"><div style="float:left;"><?php if($profile_42qu['link']) : foreach($profile_42qu['link'] as $link) : ?><a target="_blank" href="<?php echo $link[1]; ?>" style="margin-right:7px;text-decoration:none;"><?php echo $link[0]; ?></a> <?php endforeach;endif; ?></div><div><a target="_blank" href="http://42qu.com/<?php echo $user_path; ?>/pay?title=<?php echo $title; ?>&url=<?php echo urlencode($permalink); ?>&rel=<?php echo $position; ?>" style="text-decoration:none;margin-right:17px">向文章付费</a> <a href="http://42qu.com/<?php echo $user_path; ?>/pay?title=<?php echo $title; ?>&url=<?php echo urlencode($permalink); ?>&cid=1&rel=<?php echo $position; ?>" style="text-decoration:none;margin-right:16px" target="_blank">请作者吃饭</a></div></div></div>
<?php endif;
$add = ob_get_contents();
ob_end_clean();
return $content.$add;
}
add_filter('the_content', 'show_42qu_namecard', 1, 1);
add_filter('the_excerpt', 'show_42qu_namecard', 1, 1);
add_filter('the_excerpt_rss', 'show_42qu_namecard', 1, 1);
add_filter('the_excerpt_rss', 'excerpt_force_balance_tags' , 99, 10);
function excerpt_force_balance_tags ($output) {
	return $output = force_balance_tags($output);;
}
?>
